import pandas as pd
import json
import os


def structure_data(extracted_data, output_format="dict"):

    if not extracted_data:
        return {}

    if output_format == "dict":
        return extracted_data

    elif output_format == "json":
        return json.dumps(extracted_data, indent=4)

    elif output_format == "csv":
        df = pd.DataFrame([extracted_data])
        return df.to_csv(index=False)

    elif output_format == "excel":
        file_path = "records.xlsx"

        new_data = pd.DataFrame([extracted_data])

        if os.path.exists(file_path):
            existing_data = pd.read_excel(file_path)
            final_data = pd.concat([existing_data, new_data], ignore_index=True)
        else:
            final_data = new_data

        final_data.to_excel(file_path, index=False)
        return file_path

    else:
        return extracted_data


def display_data(data):
    
    if isinstance(data, dict):
        for key, value in data.items():
            print(f"{key}: {value}")
    else:
        print(data)
