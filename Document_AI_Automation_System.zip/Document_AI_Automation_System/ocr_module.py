import pytesseract
from PIL import Image
import cv2
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


def preprocess_image(image_path):

    image = cv2.imread(image_path)

    if image is None:
        raise ValueError("Invalid image file or path")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    _, threshold = cv2.threshold(
        blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    return threshold


def extract_text_from_image(image_path):
    
    processed_image = preprocess_image(image_path)
    pil_image = Image.fromarray(processed_image)

    text = pytesseract.image_to_string(pil_image)
    return text
