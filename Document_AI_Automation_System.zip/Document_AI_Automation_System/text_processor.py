import re
import pytesseract
from pdf2image import convert_from_path
import PyPDF2


def clean_text(text):
    
    if not text:
        return ""
    text = text.replace("\n", " ")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\w\s.,:/\-&]", "", text)
    return text.strip()


def extract_text_from_pdf(file_path):
    
    text = ""
    try:
        pdf_file = open(file_path, 'rb')
        reader = PyPDF2.PdfReader(pdf_file)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        pdf_file.close()
    except Exception:
        images = convert_from_path(file_path)
        for img in images:
            text += pytesseract.image_to_string(img) + "\n"
    return clean_text(text)

def extract_aadhaar_details(text):
    data = {}
    aadhaar = re.search(r"\b\d{4}[- ]?\d{4}[- ]?\d{4}\b", text)
    if aadhaar:
        data["ID Number"] = aadhaar.group().replace(" ", "").replace("-", "")
    name = re.search(r"Name\s*[:\-]?\s*([A-Za-z ]{3,})", text)
    if name:
        data["Name"] = name.group(1).strip()
    dob = re.search(r"\b\d{2}[-/]\d{2}[-/]\d{4}\b", text)
    if dob:
        data["Date of Birth"] = dob.group()
    gender = re.search(r"\b(Male|Female)\b", text, re.IGNORECASE)
    if gender:
        data["Gender"] = gender.group().title()
    return data

def extract_pan_details(text):
    data = {}
    pan = re.search(r"\b[A-Z]{5}\d{4}[A-Z]\b", text)
    if pan:
        data["ID Number"] = pan.group()
    name = re.search(r"Name\s*[:\-]?\s*([A-Za-z ]{3,})", text)
    if name:
        data["Name"] = name.group(1).strip()
    dob = re.search(r"\b\d{2}[-/]\d{2}[-/]\d{4}\b", text)
    if dob:
        data["Date of Birth"] = dob.group()
    return data

def extract_invoice_details(text):
    data = {}

    bill_no = re.search(
        r"(Invoice No|Invoice Number|Bill No)\s*[:\-]?\s*([\w\-\/]+)",
        text, re.IGNORECASE
    )
    if bill_no:
        data["Invoice Number"] = bill_no.group(2)

    name = re.search(
        r"(Customer Name|Consumer Name|Issued To|Bill To|Recipient)\s*[:\-]?\s*([A-Za-z &]{3,})",
        text, re.IGNORECASE
    )
    if name:
        data["Name"] = name.group(2).strip()
    else:
        # Fallback: first line without "invoice" or "no"
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        for line in lines:
            if "invoice" not in line.lower() and "no" not in line.lower():
                data["Name"] = line
                break

    dates = re.findall(r"\b\d{2}[./-]\d{2}[./-]\d{4}\b", text)
    if dates:
        data["Date"] = dates[0]
        if len(dates) > 1:
            data["Due Date"] = dates[1]

    amount = re.search(
        r"(Total Payable|Amount Due|Grand Total|Bill Amount)\s*[:\-]?\s*₹?\s*(\d+(?:\.\d{1,2})?)",
        text, re.IGNORECASE
    )
    if amount:
        data["Amount"] = amount.group(2)

    return data

def extract_certificate_details(text):
    data = {}
    name = re.search(r"Name\s*[:\-]?\s*([A-Za-z ]{3,})", text)
    if name:
        data["Name"] = name.group(1).strip()
    ref = re.search(
        r"(Certificate No|Registration No|Application No|Roll No)\s*[:\-]?\s*(\w+)",
        text, re.IGNORECASE
    )
    if ref:
        data["Reference Number"] = ref.group(2)
    date = re.search(r"\b\d{2}[./-]\d{2}[./-]\d{4}\b", text)
    if date:
        data["Date"] = date.group()
    return data

def process_document(file_path=None, text=None):
    """
    Unified document processor for file path or raw text.
    """
    if file_path:
        text = extract_text_from_pdf(file_path)
    elif text:
        text = clean_text(text)
    else:
        return {"Document Type": "Unknown", "Error": "No input provided"}

    lower_text = text.lower()

    if any(word in lower_text for word in [
        "invoice", "bill", "electricity", "amount due",
        "total payable", "bill amount"
    ]):
        data = extract_invoice_details(text)
        data["Document Type"] = "Invoice / Bill"

    elif re.search(r"\b[A-Z]{5}\d{4}[A-Z]\b", text):
        data = extract_pan_details(text)
        data["Document Type"] = "PAN Card"

    elif "aadhaar" in lower_text or "uidai" in lower_text:
        data = extract_aadhaar_details(text)
        data["Document Type"] = "Aadhaar Card"

    elif len(text) > 10:
        data = extract_certificate_details(text)
        data["Document Type"] = "Certificate / Form"

    else:
        data = {"Document Type": "Unknown", "Raw Text": text}

    return data

def process_text(text):
    """Wrapper for backward compatibility (raw text only)."""
    return process_document(text=text)
