from flask import Flask, render_template, request
import os

from ocr_module import extract_text_from_image
from pdf_parser import extract_text_from_pdf
from text_processor import process_document 
from data_structurer import structure_data

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "pdf"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


def allowed_file(filename):
    """Check if the uploaded file is allowed"""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def identify_document_type(file_path):
    """Determine if file is an image or PDF"""
    extension = file_path.rsplit(".", 1)[1].lower()
    if extension in ["jpg", "jpeg", "png"]:
        return "image"
    elif extension == "pdf":
        return "pdf"
    return "unknown"


@app.route("/", methods=["GET", "POST"])
def index():
    extracted_data = None
    excel_file = None

    if request.method == "POST":
        file = request.files.get("document")

        if file and allowed_file(file.filename):
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(file_path)

            try:
                # Identify document type
                doc_type = identify_document_type(file_path)

                # Extract raw text
                if doc_type == "image":
                    raw_text = extract_text_from_image(file_path)
                elif doc_type == "pdf":
                    raw_text = extract_text_from_pdf(file_path)
                else:
                    raw_text = ""

                # Process extracted text
                extracted_data = process_document(text=raw_text)

                # Save structured data to Excel
                excel_file = structure_data(extracted_data, output_format="excel")

            except Exception as error:
                extracted_data = {"Error": str(error)}

    return render_template(
        "index.html",
        data=extracted_data,
        excel_file=excel_file
    )


if __name__ == "__main__":
    app.run(debug=True)
